// // alert("whatchu doing?");
// // prompt("Enter the name","");
// console.log("Shitty day init?");
// document.write("<br><h1>Java script is a language</h1>");
// var num = 54;
// var num=0;
// let num2=90;
// num2=89;
// console.log(num);
function mul(num1,num2,num3) {
    return num1*num2*num3;
}
function inputing(){
    let person=prompt("Enter the name","");
    switch(person){
        case "Modi":
            document.write("Good choice");
            break;
        case "Rahul":
            document.write("Anti-national");
            break;
        default:
            document.write("WHo the fuck is that? Antinational leftist fuck");
            break;
    }
    // var num4= mul(num1,num2,num3);
    // alert(num4);
}
// document.write(mul(2,3,4));